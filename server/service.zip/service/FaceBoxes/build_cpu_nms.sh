cd utils
python3 build.py build_ext --inplace
cd ..