# import os
# os.environ["CUDA_VISIBLE_DEVICES"] = "2,3,4,5"


from sixdrepnet import SixDRepNet
import cv2
from math import cos
import math

model = SixDRepNet()
img = cv2.imread('3.64.jpg')

pitch, yaw, roll = model.predict(img)

model.draw_axis(img, yaw, pitch, roll)

print(cos(pitch[0]/(180/math.pi)), yaw[0], roll[0])
